package HPBA;

public class coloredNode {
	int id;
	private int color = -1;
	
	coloredNode(int id){
		this.id = id;
	}
	
	public int getColor(){
		return this.color;
	}
	
	public boolean setColor(int c){
		if(c<0 || this.color == c){
			return false;
		}else{
			this.color = c;
			return true;
		}
	}
}

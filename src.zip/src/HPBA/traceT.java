package HPBA;

class traceT {
	String input = null;
	int nextNodeIdx = -1;

	traceT(String a, int nid) {
		input = a;
		nextNodeIdx = nid;
	}
}

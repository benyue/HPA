package HPBA;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.HashSet;

import org.junit.Test;

public class test {
	@Test
	public void testHashSet() {
		HashSet<Integer> S1 = new HashSet<Integer>(2);
		S1.add(1);
		S1.add(2);

		HashSet<Integer> S2 = new HashSet<Integer>();
		S2.add(2);
		S2.add(1);

		HashSet<Integer> S3 = new HashSet<Integer>();
		S3.add(3);

		int h1 = S1.hashCode(), h2 = S2.hashCode(), h3 = S3.hashCode();

		assertEquals(S1, S2);
		assertNotEquals(S1, S3);

		HashMap<HashSet<Integer>, Integer> map = 
				new HashMap<HashSet<Integer>, Integer>();
		map.put(new HashSet<Integer>(1),0);
		map.put(new HashSet<Integer>(2),1);
		assertEquals(map.size(),1);
		map.clear();
		
		map.put(S1, 1);
		map.put(S2, 2);
		assertEquals((int)map.get(S1), 2);
		assertEquals(map.size(),1);
		assertNull(map.get(S3));
		map.put(S3, 3);
		assertEquals((int)map.get(S1), 2);
		assertEquals((int)map.get(S3), 3);

	}

	//@Test
	public void testFlagNode() {
		HashSet<flagNode> tn1 = new HashSet<flagNode>(2);
		flagNode fn1 = new flagNode(1, true);
		flagNode fn2 = new flagNode(2);
		tn1.add(fn1);
		tn1.add(fn2);
		traceVset tv1 = new traceVset(tn1);

		HashSet<flagNode> tn2 = new HashSet<flagNode>(2);
		flagNode fn3 = new flagNode(1);
		flagNode fn4 = new flagNode(2);
		tn2.add(fn3);
		tn2.add(fn4);
		traceVset tv2 = new traceVset(tn2);

		assertEquals(fn2, fn4);
		assertEquals(fn1, fn3);
		assertTrue(tn1.contains(fn1));
		assertTrue(tn1.contains(fn2));
		assertTrue(tn1.contains(fn4));
		assertTrue(tn1.contains(fn3));

		assertEquals(tn1.hashCode(), tn2.hashCode());
		assertEquals(tn1, tn2);

		assertEquals(tv1, tv2);
		// assertEquals(tv1.Vset(),tv2.Vset());
		assertTrue(tv1.equals(tv2) && tv2.equals(tv1));

		HashSet<traceVset> trace = new HashSet<traceVset>(2);
		trace.add(tv1);
		assertTrue(trace.contains(tv1));
		assertTrue(trace.contains(tv2));
		trace.add(tv2);
		assertEquals(trace.size(), 1);

		HashMap<traceVset, Integer> traceVSearchMap0 = new HashMap<traceVset, Integer>();
		traceVSearchMap0.put(tv1, 1);
		traceVSearchMap0.put(tv2, 2);
		assertEquals(traceVSearchMap0.entrySet().size(), 1);
		assertEquals((int) traceVSearchMap0.get(tv1), 2);
		assertEquals((int) traceVSearchMap0.get(tv2), 2);

		/*
		 * HashMap<HashSet<Integer>, Integer> traceVSearchMap = new
		 * HashMap<HashSet<Integer>, Integer>();
		 * traceVSearchMap.put(tv1.Vset(),1); traceVSearchMap.put(tv2.Vset(),2);
		 * assertEquals(traceVSearchMap.entrySet().size(),1);
		 */

		HashSet<flagNode> tn3 = new HashSet<flagNode>();
		flagNode fn5 = new flagNode(3);
		tn3.add(fn5);
		traceVset tv3 = new traceVset(tn3);
		assertEquals(tn1.hashCode(), tn3.hashCode());
		assertNotEquals(tn1, tn3);
		assertEquals(tv1.hashCode(), tv3.hashCode());
		assertNotEquals(tv1, tv3);
		assertFalse(trace.contains(tv3));
	}

}

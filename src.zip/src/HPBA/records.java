package HPBA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/**
 * For each node in final SCCs, maintain this record.
 * @author Cindy Yue Ben
 * */
public class records {

	int potential_WS_node = -1; // index in potential_WS_nodes in HPBA
	
	/**
	 * input a -> index in potential_WS_nodes.
	 * Size of this.potential_WS_nodes = size of this.potential_WS_matching
	 * */
	HashMap<String, Integer> potential_WS_matching 
		= new HashMap<String, Integer>();
}

package HPA;

public enum alg {
	BKD,FWD
}

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.apache.commons.math3.fraction.Fraction;

public class monitor {
	// output
	ArrayList<Character> op;
	// transition
	ArrayList<ArrayList<transition>> T;

	class transition {
		int end = -1;
		Fraction pr = Fraction.ZERO;

		public transition(int end, Fraction pr) {
			this.end = end;
			this.pr = pr;
		}
	}

	public monitor() {
		op = new ArrayList<Character>(5);
		op.add('a');// s
		op.add('b');// t
		op.add('b');// v
		op.add('a');// u
		op.add('a');// w

		// property: eventually v
		T = new ArrayList<ArrayList<transition>>(5);
		T.add(new ArrayList<transition>(2));
		T.get(0).add(new transition(1, Fraction.ONE_HALF));
		T.get(0).add(new transition(2, Fraction.ONE_HALF));
		T.add(new ArrayList<transition>(2));
		T.get(1).add(new transition(1, Fraction.THREE_QUARTERS));
		T.get(1).add(new transition(3, Fraction.ONE_QUARTER));
		T.add(new ArrayList<transition>(2));
		T.get(2).add(new transition(4, Fraction.THREE_QUARTERS));
		T.get(2).add(new transition(2, Fraction.ONE_QUARTER));
		T.add(new ArrayList<transition>(2));
		T.get(3).add(new transition(1, Fraction.THREE_QUARTERS));
		T.get(3).add(new transition(3, Fraction.ONE_QUARTER));
		T.add(new ArrayList<transition>(2));
		T.get(4).add(new transition(4, Fraction.THREE_QUARTERS));
		T.get(4).add(new transition(2, Fraction.ONE_QUARTER));
	}

	public static void main(String[] args) {
		monitor m = new monitor();

		int N = 1;
		//|state| = |prob| = |output|
		ArrayList<Integer> state = new ArrayList<Integer>();
		state.add(0);// s, initial state
		ArrayList<String> output = new ArrayList<String>();
		output.add("a");
		ArrayList<Fraction> prob = new ArrayList<Fraction>();
		prob.add(Fraction.ONE);

		while (N < 9) {
			++N;
			ArrayList<Integer> state1 = new ArrayList<Integer>();
			ArrayList<Fraction> prob1 = new ArrayList<Fraction>();
			ArrayList<String> output1 = new ArrayList<String>();
			HashMap<String, Fraction> Pr = new HashMap<String, Fraction>();
			HashMap<String, Fraction> PrBad = new HashMap<String, Fraction>();
			for (int i = 0; i < state.size(); ++i) {
				Integer s = state.get(i);
				for (transition t : m.T.get(s)) {
					state1.add(t.end);
					Fraction pr = t.pr.multiply(prob.get(i));
					prob1.add(pr);
					String o = output.get(i) + m.op.get(t.end);
					output1.add(o);
					if (Pr.get(o) == null) {
						Pr.put(o, pr);
					} else {
						Pr.put(o, Pr.get(o).add(pr));
					}
					if (t.end % 2 == 0) {// 2 or 4, good
						if (PrBad.get(o) == null) {
							PrBad.put(o, Fraction.ZERO);//ensure |PrBad| = |Pr|
						}
						continue;
					}
					// 1 or 3, bad
					if (PrBad.get(o) == null) {
						PrBad.put(o, pr);
					} else {
						PrBad.put(o, PrBad.get(o).add(pr));
					}
				}
			}
			
			state = state1;
			prob = prob1;
			output = output1;
			////For M w one-sided errors, accept if RejProb<p, else reject.
			//For M w two-sided errors, accept if rejPr<1/2, else reject.
			HashMap<String, Fraction> PrRej = new HashMap<String, Fraction>();
			HashSet<String> acpOp = new HashSet<String>(Pr.size());
			HashSet<String> rejOp = new HashSet<String>(Pr.size());
			// update PrBad as RejProb.
			for (Map.Entry<String, Fraction> e : PrBad.entrySet()) {
				Fraction rejPr = e.getValue().divide(Pr.get(e.getKey()));
				if(rejPr.compareTo(Fraction.ONE_HALF)<0) 
					acpOp.add(e.getKey());
				else rejOp.add(e.getKey());
				PrRej.put(e.getKey(), rejPr);
			}
			
			// state 1 or 3 reject, 2 or 4 accept
			Fraction tempA = Fraction.ZERO, tempR = Fraction.ZERO;
			for (int i = 0; i < state.size(); ++i) {
				String o = output.get(i);
				if(acpOp.contains(o)){
					tempA = tempA.add((Fraction.ONE.subtract(PrRej.get(o))).multiply(prob.get(i)));
				}else{
					tempR = tempR.add(PrRej.get(o).multiply(prob.get(i)));
				}
				
			}
			Fraction AA = tempA.divide(Fraction.ONE_HALF);
			Fraction RA = tempR.divide(Fraction.ONE_HALF);
			System.out.println("N="+N+": AA="+AA+", RA="+RA);
		}
	}

}
